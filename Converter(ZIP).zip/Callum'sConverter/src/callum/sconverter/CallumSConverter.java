
package callum.sconverter;

import java.util.Scanner;


public class CallumSConverter {

   
    public static void main(String[] args) {
        Scanner num=new Scanner(System.in);
        System.out.println("Enter 1 for Cm to Inches, 2 for Meters to Ft, 3 => for EXIT: ");
        int callum_variable = num.nextInt();
         
                
        switch(callum_variable){
            
        case 1:
        Scanner cm = new Scanner(System.in);
        System.out.println("Enter centimeters: ");
        double centimeters = cm.nextDouble();
        double inches = Math.round( (centimeters / 2.45) * 100) /100.0;
        System.out.println(inches +"Inches");
        break;
            
        case 2:
        Scanner m = new Scanner(System.in);
        System.out.println("Enter meters:  ");
        double meters = m.nextDouble();
        double feet = (  (meters * 3.28084) );
        System.out.println(feet +"Ft");
            
        default:
            System.exit(0);
        }
    }
}
